from tests import (GenericViewTests, InheritanceTest, ModelInheritanceTest,
    DateRangeFilterTest, FilterSetForm, AllValuesFilterTest, InitialValueTest,
    RelatedObjectTest, MultipleChoiceFilterTest, MultipleLookupTypesTest, 
    filter_tests)

__test__ = {
    'filter_tests': filter_tests,
}
