<?php 
 // created: 2011-09-13 23:19:57
$mod_strings['LBL_SUPERVISOR'] = 'SWORD Supervisor';

?>
